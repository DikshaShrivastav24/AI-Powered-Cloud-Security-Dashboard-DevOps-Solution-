#!/usr/bin/env python3
"""
pipeline/log_generator.py
Synthetic cloud security log generator for testing.
Produces realistic AWS / Azure / GCP / Kubernetes audit logs
and publishes them to Kafka topics.
"""

import json, random, time, uuid, os, logging
from datetime import datetime, timezone
from confluent_kafka import Producer

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

KAFKA_BROKERS      = os.environ.get("KAFKA_BROKERS", "localhost:29092")
EVENTS_PER_SECOND  = int(os.environ.get("EVENTS_PER_SECOND", "50"))

producer = Producer({"bootstrap.servers": KAFKA_BROKERS, "acks": 1})

# ─── Pools ───────────────────────────────────────────────────────────────────
AWS_EVENTS = [
    "GetObject","PutObject","DeleteObject","ListBuckets",
    "CreateUser","DeleteUser","AttachUserPolicy","CreateRole",
    "RunInstances","TerminateInstances","StartInstances","StopInstances",
    "DescribeInstances","CreateVpc","DeleteVpc","AuthorizeSecurityGroupIngress",
    "GetSecretValue","PutSecretValue","CreateKey","ScheduleKeyDeletion",
    "AssociateRouteTable","CreateSubnet","CreateInternetGateway",
    "PutBucketPublicAccessBlock","DeleteBucketPolicy","CreateBucket",
]
AZURE_OPS = [
    "Microsoft.Compute/virtualMachines/write",
    "Microsoft.Compute/virtualMachines/delete",
    "Microsoft.Storage/storageAccounts/write",
    "Microsoft.Authorization/roleAssignments/write",
    "Microsoft.Network/networkSecurityGroups/write",
    "Microsoft.KeyVault/vaults/secrets/read",
    "Microsoft.Sql/servers/databases/write",
    "Microsoft.Web/sites/write",
    "Microsoft.ContainerService/managedClusters/write",
]
GCP_METHODS = [
    "compute.instances.insert","compute.instances.delete",
    "storage.buckets.create","storage.objects.get",
    "iam.serviceAccounts.create","iam.roles.create",
    "container.clusters.create","cloudsql.instances.create",
    "cloudkms.cryptoKeyVersions.destroy","logging.sinks.create",
]
K8S_VERBS     = ["create","update","delete","get","list","patch","watch"]
K8S_RESOURCES = ["pods","deployments","services","secrets","configmaps",
                  "roles","rolebindings","clusterroles","namespaces","ingresses"]
IP_POOLS = {
    "normal": [f"10.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}" for _ in range(50)],
    "bad":    ["198.51.100.1","203.0.113.5","192.0.2.100","198.51.100.42","203.0.113.99"],
    "cloud":  ["13.32.0.1","52.92.0.1","104.18.0.1","35.186.0.1"],
}
USERS = ["alice@corp.com","bob@corp.com","carol@corp.com","svc-pipeline@corp.com",
         "root","admin","ANONYMOUS","unknown@evil.example"]
REGIONS = ["us-east-1","us-west-2","eu-west-1","ap-southeast-1","us-central1"]

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def weighted_ip():
    if random.random() < 0.03:
        return random.choice(IP_POOLS["bad"])
    return random.choice(IP_POOLS["normal"])

# ─── Event generators ────────────────────────────────────────────────────────

def make_aws_event(attack=False):
    event_name = (random.choice(["DeleteBucket","AttachUserPolicy","PutBucketPolicy",
                                  "CreateUser","AuthorizeSecurityGroupIngress"])
                  if attack else random.choice(AWS_EVENTS))
    return {
        "eventVersion": "1.08",
        "eventID":       str(uuid.uuid4()),
        "eventTime":     now_iso(),
        "eventName":     event_name,
        "eventSource":   f"{event_name.lower().split('put')[0]}.amazonaws.com",
        "awsRegion":     random.choice(REGIONS[:3]),
        "sourceIPAddress": weighted_ip() if not attack else random.choice(IP_POOLS["bad"]),
        "userAgent":     random.choice(["aws-cli/2.x","boto3/1.x","Terraform/1.x",
                                         "console.amazonaws.com","curl/7.x"]),
        "userIdentity": {
            "type": "IAMUser",
            "arn":  f"arn:aws:iam::123456789012:user/{random.choice(USERS)}",
            "accountId": "123456789012",
        },
        "requestParameters": {"bucketName": f"corp-bucket-{random.randint(1,20)}"},
        "errorCode": ("AccessDenied" if attack and random.random() < 0.3 else None),
        "errorMessage": ("User is not authorized" if attack and random.random() < 0.3 else None),
    }

def make_azure_event(attack=False):
    return {
        "time":           now_iso(),
        "category":       random.choice(["Administrative","Security","Policy"]),
        "operationName":  (random.choice(["Microsoft.Authorization/roleAssignments/write",
                                           "Microsoft.Compute/virtualMachines/delete"])
                           if attack else random.choice(AZURE_OPS)),
        "resultType":     "Failure" if attack else random.choice(["Success","Success","Success","Failure"]),
        "callerIpAddress": weighted_ip() if not attack else random.choice(IP_POOLS["bad"]),
        "identity": {
            "claims": {"upn": random.choice(USERS)}
        },
        "location":      random.choice(["eastus","westeurope","southeastasia"]),
        "resourceType":  random.choice(["virtualMachines","storageAccounts","databases"]),
        "correlationId": str(uuid.uuid4()),
    }

def make_gcp_event(attack=False):
    return {
        "timestamp":  now_iso(),
        "logName":    "projects/my-project/logs/cloudaudit.googleapis.com",
        "severity":   "ERROR" if attack else random.choice(["INFO","INFO","INFO","WARNING"]),
        "resource": {
            "type": random.choice(["gce_instance","gcs_bucket","k8s_cluster"]),
            "labels": {"location": random.choice(REGIONS[2:])},
        },
        "protoPayload": {
            "methodName": (random.choice(["iam.serviceAccounts.create","cloudkms.cryptoKeyVersions.destroy"])
                           if attack else random.choice(GCP_METHODS)),
            "authenticationInfo": {"principalEmail": random.choice(USERS)},
            "requestMetadata": {"callerIp": weighted_ip() if not attack else random.choice(IP_POOLS["bad"])},
            "status": {"code": 7 if attack else 0, "message": "PERMISSION_DENIED" if attack else "OK"},
        },
    }

def make_k8s_event(attack=False):
    verb     = "delete" if attack else random.choice(K8S_VERBS)
    resource = "secrets" if attack else random.choice(K8S_RESOURCES)
    return {
        "requestReceivedTimestamp": now_iso(),
        "verb":     verb,
        "user":     {"username": "system:anonymous" if attack else random.choice(USERS)},
        "sourceIPs": [weighted_ip() if not attack else random.choice(IP_POOLS["bad"])],
        "objectRef": {
            "resource":  resource,
            "namespace": random.choice(["default","kube-system","prod","staging"]),
            "name":      f"{resource[:-1]}-{random.randint(1,100)}",
        },
        "responseStatus": {"code": 403 if attack else random.choice([200,201,200,200,404])},
        "userAgent": "kubectl/1.28 (linux/amd64)",
    }

GENERATORS = {
    "cloud-logs-aws":   make_aws_event,
    "cloud-logs-azure": make_azure_event,
    "cloud-logs-gcp":   make_gcp_event,
    "cloud-logs-k8s":   make_k8s_event,
}

def delivery_cb(err, msg):
    if err:
        log.error("Delivery error: %s", err)

def run():
    log.info("Log generator started — %d events/sec", EVENTS_PER_SECOND)
    count = 0
    delay = 1.0 / EVENTS_PER_SECOND

    while True:
        topic, gen = random.choice(list(GENERATORS.items()))
        # 5% chance of simulated attack event
        attack = random.random() < 0.05
        event  = gen(attack=attack)

        producer.produce(
            topic,
            json.dumps(event).encode("utf-8"),
            callback=delivery_cb,
        )
        count += 1
        if count % 1000 == 0:
            producer.poll(0)
            log.info("Generated %d events (attacks simulated: ~5%%)", count)

        time.sleep(delay)

if __name__ == "__main__":
    run()
