#!/usr/bin/env python3
"""
pipeline/kafka_pipeline.py
Real-time security log pipeline using Kafka
──────────────────────────────────────────
Flow:
  Cloud Logs → Fluentd → Kafka Topics → Stream Processor → Elasticsearch
                                      → ML Inference     → Alert Engine
"""

import os, json, logging, asyncio
from datetime import datetime, timezone
from typing import Optional
from confluent_kafka import Consumer, Producer, KafkaError
from elasticsearch import Elasticsearch, helpers

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

# ─── Config ──────────────────────────────────────────────────────────────────
KAFKA_BROKERS  = os.environ.get("KAFKA_BROKERS", "kafka:9092")
ES_URL         = os.environ.get("ELASTICSEARCH_URL", "http://elasticsearch:9200")
ML_API_URL     = os.environ.get("ML_API_URL", "http://ml-service:5001")
ML_API_KEY     = os.environ.get("ML_API_KEY", "ml-secret-key")

TOPICS = {
    "aws":           "cloud-logs-aws",
    "azure":         "cloud-logs-azure",
    "gcp":           "cloud-logs-gcp",
    "kubernetes":    "cloud-logs-k8s",
    "enriched":      "security-enriched",
    "alerts":        "security-alerts",
    "ml_scores":     "ml-threat-scores",
}

CONSUMER_CONF = {
    "bootstrap.servers":  KAFKA_BROKERS,
    "group.id":           "security-pipeline",
    "auto.offset.reset":  "earliest",
    "enable.auto.commit": False,
    "max.poll.interval.ms": 300_000,
}

PRODUCER_CONF = {
    "bootstrap.servers": KAFKA_BROKERS,
    "acks":              "all",
    "retries":           5,
    "batch.size":        65536,
    "linger.ms":         10,
    "compression.type":  "snappy",
}

# ─── Elasticsearch ────────────────────────────────────────────────────────────
es = Elasticsearch(
    ES_URL,
    basic_auth=(
        os.environ.get("ES_USER", "elastic"),
        os.environ.get("ES_PASS", "changeme"),
    ),
    request_timeout=30,
)

# ─── Normalizer ───────────────────────────────────────────────────────────────
class LogNormalizer:
    """Normalizes logs from different cloud providers to a unified schema."""

    def normalize(self, raw: dict, source: str) -> Optional[dict]:
        try:
            if source == "aws":
                return self._normalize_aws(raw)
            elif source == "azure":
                return self._normalize_azure(raw)
            elif source == "gcp":
                return self._normalize_gcp(raw)
            elif source == "kubernetes":
                return self._normalize_k8s(raw)
            return None
        except Exception as e:
            log.warning("Normalization error for %s: %s", source, e)
            return None

    def _normalize_aws(self, r: dict) -> dict:
        return {
            "@timestamp":    r.get("eventTime", datetime.now(timezone.utc).isoformat()),
            "cloud_provider":"aws",
            "event_name":    r.get("eventName", ""),
            "event_source":  r.get("eventSource", ""),
            "source_ip":     r.get("sourceIPAddress", ""),
            "user_agent":    r.get("userAgent", ""),
            "user_identity": r.get("userIdentity", {}).get("arn", ""),
            "region":        r.get("awsRegion", ""),
            "error_code":    r.get("errorCode"),
            "resource_type": r.get("requestParameters", {}).get("resourceType", ""),
            "raw":           r,
        }

    def _normalize_azure(self, r: dict) -> dict:
        return {
            "@timestamp":    r.get("time", datetime.now(timezone.utc).isoformat()),
            "cloud_provider":"azure",
            "event_name":    r.get("operationName", ""),
            "event_source":  r.get("category", ""),
            "source_ip":     r.get("callerIpAddress", ""),
            "user_identity": r.get("identity", {}).get("claims", {}).get("upn", ""),
            "region":        r.get("location", ""),
            "status":        r.get("resultType", ""),
            "resource_type": r.get("resourceType", ""),
            "raw":           r,
        }

    def _normalize_gcp(self, r: dict) -> dict:
        payload = r.get("protoPayload", r)
        return {
            "@timestamp":    r.get("timestamp", datetime.now(timezone.utc).isoformat()),
            "cloud_provider":"gcp",
            "event_name":    payload.get("methodName", ""),
            "event_source":  r.get("resource", {}).get("type", ""),
            "source_ip":     payload.get("requestMetadata", {}).get("callerIp", ""),
            "user_identity": payload.get("authenticationInfo", {}).get("principalEmail", ""),
            "region":        r.get("resource", {}).get("labels", {}).get("location", ""),
            "status":        payload.get("status", {}).get("code"),
            "raw":           r,
        }

    def _normalize_k8s(self, r: dict) -> dict:
        return {
            "@timestamp":    r.get("requestReceivedTimestamp", datetime.now(timezone.utc).isoformat()),
            "cloud_provider":"kubernetes",
            "event_name":    f"{r.get('verb','')} {r.get('objectRef',{}).get('resource','')}",
            "event_source":  "k8s-audit",
            "source_ip":     r.get("sourceIPs", [""])[0],
            "user_identity": r.get("user", {}).get("username", ""),
            "namespace":     r.get("objectRef", {}).get("namespace", ""),
            "resource":      r.get("objectRef", {}).get("resource", ""),
            "verb":          r.get("verb", ""),
            "response_code": r.get("responseStatus", {}).get("code"),
            "raw":           r,
        }


# ─── Enrichment ───────────────────────────────────────────────────────────────
class EventEnricher:
    """Add threat intelligence, geo-location, and computed fields."""

    # Simplified threat IP list – in prod, integrate with MISP / VirusTotal
    KNOWN_BAD_IPS = {"198.51.100.1", "203.0.113.5", "192.0.2.100"}
    HIGH_RISK_OPS = {
        "DeleteBucket", "PutBucketPolicy", "CreateUser", "AttachUserPolicy",
        "RunInstances", "TerminateInstances", "DeleteVpc", "ModifyImageAttribute",
    }

    def enrich(self, event: dict) -> dict:
        event["is_threat_ip"]   = event.get("source_ip", "") in self.KNOWN_BAD_IPS
        event["is_high_risk_op"]= event.get("event_name", "") in self.HIGH_RISK_OPS
        event["has_error"]      = bool(event.get("error_code") or
                                       (event.get("response_code", 200) >= 400))
        event["enriched_at"]    = datetime.now(timezone.utc).isoformat()

        # Derived risk signals
        signals = sum([
            event["is_threat_ip"],
            event["is_high_risk_op"],
            event["has_error"],
            "root" in str(event.get("user_identity", "")).lower(),
            event.get("response_code", 200) in (403, 401),
        ])
        event["initial_risk_level"] = ("high" if signals >= 3 else
                                        "medium" if signals >= 1 else "low")
        return event


# ─── Elasticsearch Writer ─────────────────────────────────────────────────────
class ElasticsearchWriter:
    def __init__(self, batch_size: int = 500):
        self.buffer    = []
        self.batch_size = batch_size

    def add(self, event: dict, index_prefix: str = "security-logs"):
        date_str = datetime.now(timezone.utc).strftime("%Y.%m.%d")
        self.buffer.append({
            "_index": f"{index_prefix}-{date_str}",
            "_source": event,
        })
        if len(self.buffer) >= self.batch_size:
            self.flush()

    def flush(self):
        if not self.buffer:
            return
        try:
            success, errors = helpers.bulk(es, self.buffer, raise_on_error=False)
            log.info("ES bulk: %d success, %d errors", success, len(errors))
            if errors:
                log.warning("ES errors: %s", errors[:3])
        except Exception as e:
            log.error("ES bulk error: %s", e)
        finally:
            self.buffer.clear()


# ─── Main Pipeline ────────────────────────────────────────────────────────────
class SecurityPipeline:
    def __init__(self):
        self.normalizer = LogNormalizer()
        self.enricher   = EventEnricher()
        self.es_writer  = ElasticsearchWriter()
        self.producer   = Producer(PRODUCER_CONF)
        self.consumer   = Consumer(CONSUMER_CONF)
        self.running    = False

    def start(self):
        topics = [TOPICS["aws"], TOPICS["azure"], TOPICS["gcp"], TOPICS["kubernetes"]]
        self.consumer.subscribe(topics)
        self.running = True
        log.info("Pipeline started. Subscribed to: %s", topics)

        processed = 0
        try:
            while self.running:
                msg = self.consumer.poll(timeout=1.0)
                if msg is None:
                    continue
                if msg.error():
                    if msg.error().code() == KafkaError._PARTITION_EOF:
                        continue
                    log.error("Kafka error: %s", msg.error())
                    continue

                try:
                    raw    = json.loads(msg.value().decode("utf-8"))
                    source = self._topic_to_source(msg.topic())
                    event  = self.normalizer.normalize(raw, source)
                    if event is None:
                        continue
                    event = self.enricher.enrich(event)

                    # Write to ES
                    self.es_writer.add(event)

                    # Forward high-risk events to ML topic
                    if event["initial_risk_level"] in ("high", "medium"):
                        self.producer.produce(
                            TOPICS["enriched"],
                            json.dumps(event).encode("utf-8"),
                            callback=self._delivery_callback,
                        )

                    self.consumer.commit(asynchronous=True)
                    processed += 1
                    if processed % 1000 == 0:
                        log.info("Processed %d events", processed)
                        self.es_writer.flush()
                        self.producer.poll(0)

                except json.JSONDecodeError as e:
                    log.warning("JSON decode error: %s", e)
                except Exception as e:
                    log.exception("Processing error: %s", e)

        except KeyboardInterrupt:
            log.info("Shutting down pipeline")
        finally:
            self.es_writer.flush()
            self.producer.flush()
            self.consumer.close()

    def _topic_to_source(self, topic: str) -> str:
        return topic.split("-")[-1]   # cloud-logs-aws → aws

    @staticmethod
    def _delivery_callback(err, msg):
        if err:
            log.error("Message delivery failed: %s", err)


if __name__ == "__main__":
    pipeline = SecurityPipeline()
    pipeline.start()
