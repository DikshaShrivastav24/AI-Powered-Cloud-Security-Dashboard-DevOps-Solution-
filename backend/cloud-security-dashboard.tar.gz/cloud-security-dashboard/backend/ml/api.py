#!/usr/bin/env python3
"""
ml/api.py  –  Flask REST API wrapping all ML models
Endpoints:
  POST /predict/anomaly
  POST /predict/attack-type
  POST /predict/threat
  POST /score/risk
  GET  /models/status
"""

import os, json, logging
import numpy as np
import pandas as pd
from flask import Flask, request, jsonify
from flask_cors import CORS
from functools import wraps

from models import AnomalyDetector, AttackClassifier, RiskScorer, ThreatPredictor

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# ─── Load models ─────────────────────────────────────────────────────────────
anomaly_det  = AnomalyDetector()
classifier   = AttackClassifier()
risk_scorer  = RiskScorer()
threat_pred  = ThreatPredictor()

MODEL_STATUS = {"anomaly": False, "classifier": False, "risk": False, "lstm": False}

try:
    anomaly_det.load();   MODEL_STATUS["anomaly"]    = True
except Exception as e:  log.warning("Anomaly model not loaded: %s", e)
try:
    classifier.load();    MODEL_STATUS["classifier"] = True
except Exception as e:  log.warning("Classifier not loaded: %s", e)
try:
    risk_scorer.load();   MODEL_STATUS["risk"]       = True
except Exception as e:  log.warning("Risk scorer not loaded: %s", e)
try:
    threat_pred.load();   MODEL_STATUS["lstm"]       = True
except Exception as e:  log.warning("LSTM not loaded: %s", e)


# ─── Auth decorator ───────────────────────────────────────────────────────────
def require_api_key(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        key = request.headers.get("X-API-Key")
        if key != os.environ.get("ML_API_KEY", "ml-secret-key"):
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated


# ─── Endpoints ────────────────────────────────────────────────────────────────

@app.route("/health")
def health():
    return jsonify({"status": "ok", "models": MODEL_STATUS})

@app.route("/models/status")
@require_api_key
def model_status():
    return jsonify(MODEL_STATUS)


@app.route("/predict/anomaly", methods=["POST"])
@require_api_key
def predict_anomaly():
    """
    Input:  { "events": [ { feature_dict }, ... ] }
    Output: { "results": [ { "is_anomaly", "anomaly_score", "severity" }, ... ] }
    """
    if not MODEL_STATUS["anomaly"]:
        return jsonify({"error": "Anomaly model not available"}), 503
    try:
        data = request.get_json()
        events = data.get("events", [data])
        df = pd.DataFrame(events)
        results = anomaly_det.predict(df)
        return jsonify({"results": results, "count": len(results)})
    except Exception as e:
        log.exception("Anomaly prediction error")
        return jsonify({"error": str(e)}), 500


@app.route("/predict/attack-type", methods=["POST"])
@require_api_key
def predict_attack_type():
    """
    Input:  { "events": [ { feature_dict }, ... ] }
    Output: { "results": [ { "attack_type", "confidence", "class_probabilities" }, ... ] }
    """
    if not MODEL_STATUS["classifier"]:
        return jsonify({"error": "Classifier not available"}), 503
    try:
        data = request.get_json()
        events = data.get("events", [data])
        df = pd.DataFrame(events)
        results = classifier.predict(df)
        return jsonify({"results": results})
    except Exception as e:
        log.exception("Classification error")
        return jsonify({"error": str(e)}), 500


@app.route("/predict/threat", methods=["POST"])
@require_api_key
def predict_threat():
    """
    Input:  { "time_series": [ { feature_dict }, ... ] }  (chronological)
    Output: { "probability", "prediction", "confidence" }
    """
    if not MODEL_STATUS["lstm"]:
        return jsonify({"error": "LSTM model not available"}), 503
    try:
        data = request.get_json()
        series = data.get("time_series", [])
        df = pd.DataFrame(series)
        result = threat_pred.predict(df)
        return jsonify(result)
    except Exception as e:
        log.exception("Threat prediction error")
        return jsonify({"error": str(e)}), 500


@app.route("/score/risk", methods=["POST"])
@require_api_key
def score_risk():
    """
    Input:  { feature_dict }
    Output: { "risk_score": float (0-100) }
    """
    if not MODEL_STATUS["risk"]:
        return jsonify({"error": "Risk scorer not available"}), 503
    try:
        features = request.get_json()
        score = risk_scorer.score(features)
        return jsonify({"risk_score": score, "severity": _score_to_severity(score)})
    except Exception as e:
        log.exception("Risk scoring error")
        return jsonify({"error": str(e)}), 500


@app.route("/batch/analyze", methods=["POST"])
@require_api_key
def batch_analyze():
    """
    Full pipeline: anomaly + classification + risk for each event.
    Input:  { "events": [ { feature_dict }, ... ] }
    """
    try:
        data = request.get_json()
        events = data.get("events", [])
        df = pd.DataFrame(events)

        results = []
        anomalies = anomaly_det.predict(df) if MODEL_STATUS["anomaly"] else [{}] * len(events)
        attacks   = classifier.predict(df)  if MODEL_STATUS["classifier"] else [{}] * len(events)

        for i, event in enumerate(events):
            risk = risk_scorer.score(event) if MODEL_STATUS["risk"] else 50.0
            results.append({
                "event_index": i,
                "anomaly":     anomalies[i],
                "attack_type": attacks[i],
                "risk_score":  risk,
            })
        return jsonify({"results": results})
    except Exception as e:
        log.exception("Batch analysis error")
        return jsonify({"error": str(e)}), 500


def _score_to_severity(score: float) -> str:
    if score >= 80: return "critical"
    if score >= 60: return "high"
    if score >= 40: return "medium"
    if score >= 20: return "low"
    return "info"


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=False)
