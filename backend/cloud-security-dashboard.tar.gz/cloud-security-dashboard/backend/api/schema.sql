-- backend/api/schema.sql
-- ═══════════════════════════════════════════════════════════════
--  AI-Powered Cloud Security Dashboard – Database Schema
-- ═══════════════════════════════════════════════════════════════

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── Users ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username      VARCHAR(100) UNIQUE NOT NULL,
  email         VARCHAR(255) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role          VARCHAR(50) NOT NULL DEFAULT 'viewer'
                  CHECK (role IN ('admin','analyst','viewer')),
  mfa_enabled   BOOLEAN DEFAULT FALSE,
  last_login    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Alerts ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS alerts (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title           TEXT NOT NULL,
  description     TEXT,
  severity        VARCHAR(20) NOT NULL CHECK (severity IN ('critical','high','medium','low','info')),
  status          VARCHAR(20) NOT NULL DEFAULT 'open'
                    CHECK (status IN ('open','investigating','resolved','false_positive')),
  cloud_provider  VARCHAR(20) CHECK (cloud_provider IN ('aws','azure','gcp','kubernetes')),
  resource_id     TEXT,
  threat_type     VARCHAR(100),
  ml_confidence   FLOAT,
  assigned_to     UUID REFERENCES users(id),
  notes           TEXT,
  raw_event       JSONB,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_alerts_severity ON alerts(severity);
CREATE INDEX idx_alerts_status   ON alerts(status);
CREATE INDEX idx_alerts_created  ON alerts(created_at DESC);

-- ─── Incidents ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS incidents (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title           TEXT NOT NULL,
  description     TEXT,
  severity        VARCHAR(20) NOT NULL,
  status          VARCHAR(30) DEFAULT 'open'
                    CHECK (status IN ('open','investigating','contained','resolved','closed')),
  cloud_provider  VARCHAR(20),
  mttd_minutes    INT,
  mttr_minutes    INT,
  created_by      UUID REFERENCES users(id),
  assigned_team   TEXT,
  timeline        JSONB DEFAULT '[]',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  resolved_at     TIMESTAMPTZ
);

-- ─── Compliance Results ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS compliance_results (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  framework       VARCHAR(50) NOT NULL,   -- PCI-DSS, HIPAA, SOC2, GDPR, ISO27001
  control_id      VARCHAR(50) NOT NULL,
  control_name    TEXT NOT NULL,
  status          VARCHAR(20) NOT NULL CHECK (status IN ('pass','fail','warning','not_applicable')),
  score           FLOAT DEFAULT 0,
  evidence        TEXT,
  cloud_provider  VARCHAR(20),
  last_checked    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (framework, control_id, cloud_provider)
);
CREATE INDEX idx_compliance_framework ON compliance_results(framework);

-- ─── Vulnerabilities ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS vulnerabilities (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cve_id          VARCHAR(30),
  title           TEXT NOT NULL,
  description     TEXT,
  severity        VARCHAR(20) NOT NULL,
  cvss_score      FLOAT,
  cloud_provider  VARCHAR(20),
  resource_type   VARCHAR(100),
  resource_id     TEXT,
  package_name    TEXT,
  package_version TEXT,
  fixed_version   TEXT,
  status          VARCHAR(20) DEFAULT 'open',
  discovered_at   TIMESTAMPTZ DEFAULT NOW(),
  remediated_at   TIMESTAMPTZ
);
CREATE INDEX idx_vuln_severity   ON vulnerabilities(severity);
CREATE INDEX idx_vuln_cvss       ON vulnerabilities(cvss_score DESC);
CREATE INDEX idx_vuln_cloud      ON vulnerabilities(cloud_provider);

-- ─── Cloud Resources ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cloud_resources (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cloud_provider  VARCHAR(20) NOT NULL,
  resource_type   VARCHAR(100) NOT NULL,
  resource_id     TEXT NOT NULL,
  resource_name   TEXT,
  region          VARCHAR(50),
  risk_level      VARCHAR(20) DEFAULT 'low',
  tags            JSONB DEFAULT '{}',
  last_scanned    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (cloud_provider, resource_id)
);

-- ─── Playbooks ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS playbooks (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            TEXT NOT NULL,
  trigger_type    VARCHAR(100),
  actions         JSONB NOT NULL DEFAULT '[]',
  enabled         BOOLEAN DEFAULT TRUE,
  run_count       INT DEFAULT 0,
  last_run        TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Seed Data ───────────────────────────────────────────────────────────────
INSERT INTO users (username, email, password_hash, role) VALUES
  ('admin',   'admin@securitydashboard.io',   'demo123', 'admin'),
  ('analyst', 'analyst@securitydashboard.io', 'demo123', 'analyst'),
  ('viewer',  'viewer@securitydashboard.io',  'demo123', 'viewer')
ON CONFLICT DO NOTHING;

INSERT INTO alerts (title, severity, status, cloud_provider, threat_type, ml_confidence) VALUES
  ('Unusual API call from unknown IP',     'critical', 'open',          'aws',        'Anomaly',           0.97),
  ('Multiple failed SSH login attempts',   'high',     'investigating',  'gcp',        'BruteForce',        0.91),
  ('Privilege escalation detected',        'critical', 'open',          'azure',      'PrivilegeEsc',      0.95),
  ('Large data exfiltration attempt',      'high',     'open',          'aws',        'DataExfiltration',  0.88),
  ('Cryptomining process detected',        'medium',   'resolved',      'gcp',        'Cryptomining',      0.82),
  ('Public S3 bucket exposed',             'high',     'open',          'aws',        'Misconfiguration',  0.99),
  ('DDoS attack pattern detected',         'critical', 'open',          'azure',      'DDoS',              0.94),
  ('Suspicious container runtime activity','high',     'open',          'kubernetes', 'ContainerEscape',   0.87),
  ('Unencrypted data store found',         'medium',   'open',          'gcp',        'Misconfiguration',  0.76),
  ('Expired SSL certificate',              'low',      'open',          'aws',        'Compliance',        0.99)
ON CONFLICT DO NOTHING;

INSERT INTO compliance_results (framework, control_id, control_name, status, score, cloud_provider) VALUES
  ('PCI-DSS',  '1.1',   'Network security controls',          'pass',    100, 'aws'),
  ('PCI-DSS',  '2.1',   'Default credentials changed',        'fail',    0,   'aws'),
  ('PCI-DSS',  '3.4',   'PAN data encryption at rest',        'pass',    100, 'aws'),
  ('PCI-DSS',  '6.3',   'Security vulnerabilities addressed', 'warning', 65,  'aws'),
  ('HIPAA',    'S1',    'Access controls',                    'pass',    95,  'azure'),
  ('HIPAA',    'S2',    'Audit controls',                     'pass',    88,  'azure'),
  ('HIPAA',    'S3',    'Integrity controls',                 'warning', 72,  'azure'),
  ('SOC2',     'CC6.1', 'Logical access security',           'pass',    92,  'gcp'),
  ('SOC2',     'CC6.6', 'System boundaries protection',       'pass',    87,  'gcp'),
  ('SOC2',     'CC7.2', 'System monitoring',                  'warning', 70,  'gcp'),
  ('GDPR',     'Art32', 'Security of processing',             'pass',    90,  'aws'),
  ('GDPR',     'Art33', 'Breach notification',                'fail',    0,   'aws')
ON CONFLICT DO NOTHING;

INSERT INTO vulnerabilities (cve_id, title, severity, cvss_score, cloud_provider, resource_type, package_name) VALUES
  ('CVE-2024-1234', 'Remote code execution in nginx',       'critical', 9.8, 'aws',   'EC2',       'nginx'),
  ('CVE-2024-2345', 'SQL injection in app framework',       'high',     8.1, 'azure', 'AppService','django'),
  ('CVE-2024-3456', 'Privilege escalation in kernel',       'high',     7.8, 'gcp',   'GCE',       'linux-kernel'),
  ('CVE-2024-4567', 'Weak cryptography in TLS library',     'medium',   5.9, 'aws',   'Lambda',    'openssl'),
  ('CVE-2024-5678', 'Path traversal in file handler',       'medium',   6.5, 'gcp',   'CloudRun',  'express'),
  ('CVE-2024-6789', 'DoS via crafted HTTP request',         'low',      3.7, 'azure', 'AKS',       'http-parser')
ON CONFLICT DO NOTHING;

INSERT INTO cloud_resources (cloud_provider, resource_type, resource_id, resource_name, region, risk_level) VALUES
  ('aws',   'EC2',          'i-0abc123def456',  'prod-web-01',    'us-east-1',      'high'),
  ('aws',   'S3',           'bucket-prod-data',  'prod-data',      'us-east-1',      'medium'),
  ('aws',   'RDS',          'db-prod-001',       'prod-database',  'us-east-1',      'low'),
  ('aws',   'Lambda',       'fn-processor',      'data-processor', 'us-east-1',      'low'),
  ('azure', 'VirtualMachine','vm-prod-01',       'prod-vm-01',     'eastus',         'medium'),
  ('azure', 'AppService',   'app-prod-01',       'prod-webapp',    'eastus',         'low'),
  ('gcp',   'GCE',          'instance-prod-01',  'prod-instance',  'us-central1-a',  'high'),
  ('gcp',   'CloudRun',     'service-api-01',    'prod-api',       'us-central1',    'low')
ON CONFLICT DO NOTHING;
