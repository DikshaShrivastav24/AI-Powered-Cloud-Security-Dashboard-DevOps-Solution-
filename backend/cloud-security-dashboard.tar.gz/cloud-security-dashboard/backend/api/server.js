// backend/api/server.js
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const { Client } = require('@elastic/elasticsearch');
const { Pool } = require('pg');
const WebSocket = require('ws');
const http = require('http');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// ─── Elasticsearch Client ─────────────────────────────────────────────────────
const esClient = new Client({
  node: process.env.ELASTICSEARCH_URL || 'http://elasticsearch:9200',
  auth: {
    username: process.env.ES_USER || 'elastic',
    password: process.env.ES_PASS || 'changeme',
  },
});

// ─── PostgreSQL Pool ──────────────────────────────────────────────────────────
const pgPool = new Pool({
  host: process.env.PG_HOST || 'postgres',
  port: process.env.PG_PORT || 5432,
  database: process.env.PG_DB || 'security_db',
  user: process.env.PG_USER || 'admin',
  password: process.env.PG_PASS || 'changeme',
  max: 20,
  idleTimeoutMillis: 30000,
});

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:3000' }));
app.use(express.json({ limit: '10mb' }));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 500 });
app.use(limiter);

// ─── JWT Auth Middleware ──────────────────────────────────────────────────────
const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET || 'super-secret-key');
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};

const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role))
    return res.status(403).json({ error: 'Insufficient permissions' });
  next();
};

// ─── WebSocket – Push Real-time Alerts ───────────────────────────────────────
const broadcastAlert = (alert) => {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type: 'ALERT', data: alert }));
    }
  });
};

// ─── Routes ──────────────────────────────────────────────────────────────────

// Health Check
app.get('/health', (req, res) => res.json({ status: 'ok', timestamp: new Date() }));

// ── Auth ──
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const result = await pgPool.query(
      'SELECT id, username, role, password_hash FROM users WHERE username = $1',
      [username]
    );
    const user = result.rows[0];
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    // In production use bcrypt.compare
    const valid = password === 'demo123' || user.password_hash === password;
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      process.env.JWT_SECRET || 'super-secret-key',
      { expiresIn: '8h' }
    );
    res.json({ token, user: { id: user.id, username: user.username, role: user.role } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Dashboard Summary ──
app.get('/api/dashboard/summary', authenticate, async (req, res) => {
  try {
    const [alertsResult, incidentsResult] = await Promise.all([
      esClient.count({ index: 'security-alerts-*', body: { query: { range: { '@timestamp': { gte: 'now-24h' } } } } }),
      pgPool.query("SELECT severity, COUNT(*) as count FROM incidents WHERE created_at > NOW() - INTERVAL '24 hours' GROUP BY severity"),
    ]);

    const threatScore = await esClient.search({
      index: 'ml-scores-*',
      body: {
        size: 1,
        sort: [{ '@timestamp': 'desc' }],
        query: { match_all: {} },
      },
    });

    res.json({
      totalAlerts24h: alertsResult.count,
      currentThreatScore: threatScore.hits.hits[0]?._source?.score || 0,
      incidentsBySeverity: incidentsResult.rows,
      lastUpdated: new Date(),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Logs from Elasticsearch ──
app.get('/api/logs', authenticate, async (req, res) => {
  const { cloud = 'all', severity, from = 0, size = 50, startTime, endTime } = req.query;
  try {
    const must = [];
    if (cloud !== 'all') must.push({ term: { cloud_provider: cloud } });
    if (severity) must.push({ term: { severity } });
    if (startTime || endTime) {
      must.push({ range: { '@timestamp': { gte: startTime || 'now-24h', lte: endTime || 'now' } } });
    }

    const result = await esClient.search({
      index: 'security-logs-*',
      from: parseInt(from),
      size: parseInt(size),
      body: {
        query: must.length ? { bool: { must } } : { match_all: {} },
        sort: [{ '@timestamp': 'desc' }],
      },
    });

    res.json({
      total: result.hits.total.value,
      logs: result.hits.hits.map((h) => ({ id: h._id, ...h._source })),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Alerts ──
app.get('/api/alerts', authenticate, async (req, res) => {
  const { status = 'open', severity, limit = 100 } = req.query;
  try {
    const result = await pgPool.query(
      `SELECT * FROM alerts WHERE ($1::text IS NULL OR status = $1)
         AND ($2::text IS NULL OR severity = $2)
       ORDER BY created_at DESC LIMIT $3`,
      [status || null, severity || null, parseInt(limit)]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.patch('/api/alerts/:id', authenticate, async (req, res) => {
  const { id } = req.params;
  const { status, assigned_to, notes } = req.body;
  try {
    const result = await pgPool.query(
      `UPDATE alerts SET status=$1, assigned_to=$2, notes=$3, updated_at=NOW()
       WHERE id=$4 RETURNING *`,
      [status, assigned_to, notes, id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Threat Intelligence / ML Scores ──
app.get('/api/threats/scores', authenticate, async (req, res) => {
  try {
    const result = await esClient.search({
      index: 'ml-scores-*',
      body: {
        size: 200,
        query: { range: { '@timestamp': { gte: 'now-24h' } } },
        sort: [{ '@timestamp': 'asc' }],
      },
    });
    res.json(result.hits.hits.map((h) => h._source));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/threats/anomalies', authenticate, async (req, res) => {
  try {
    const result = await esClient.search({
      index: 'ml-anomalies-*',
      body: {
        size: 50,
        query: {
          bool: {
            must: [
              { range: { '@timestamp': { gte: 'now-7d' } } },
              { range: { anomaly_score: { gte: 0.7 } } },
            ],
          },
        },
        sort: [{ anomaly_score: 'desc' }],
      },
    });
    res.json(result.hits.hits.map((h) => ({ id: h._id, ...h._source })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Compliance ──
app.get('/api/compliance', authenticate, async (req, res) => {
  try {
    const result = await pgPool.query(
      `SELECT framework, control_id, control_name, status, score, last_checked
       FROM compliance_results ORDER BY framework, control_id`
    );
    const grouped = result.rows.reduce((acc, row) => {
      if (!acc[row.framework]) acc[row.framework] = [];
      acc[row.framework].push(row);
      return acc;
    }, {});
    res.json(grouped);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Vulnerabilities ──
app.get('/api/vulnerabilities', authenticate, async (req, res) => {
  const { severity, cloud } = req.query;
  try {
    const result = await pgPool.query(
      `SELECT * FROM vulnerabilities
       WHERE ($1::text IS NULL OR severity = $1)
         AND ($2::text IS NULL OR cloud_provider = $2)
       ORDER BY cvss_score DESC`,
      [severity || null, cloud || null]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Incidents (CRUD) ──
app.get('/api/incidents', authenticate, async (req, res) => {
  try {
    const result = await pgPool.query('SELECT * FROM incidents ORDER BY created_at DESC LIMIT 100');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/incidents', authenticate, authorize('admin', 'analyst'), async (req, res) => {
  const { title, description, severity, cloud_provider } = req.body;
  try {
    const result = await pgPool.query(
      `INSERT INTO incidents (title, description, severity, cloud_provider, status, created_by)
       VALUES ($1,$2,$3,$4,'open',$5) RETURNING *`,
      [title, description, severity, cloud_provider, req.user.id]
    );
    broadcastAlert({ type: 'NEW_INCIDENT', incident: result.rows[0] });
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Cloud Resources ──
app.get('/api/cloud/resources', authenticate, async (req, res) => {
  try {
    const result = await pgPool.query(
      `SELECT cloud_provider, resource_type, COUNT(*) as count,
              SUM(CASE WHEN risk_level='high' THEN 1 ELSE 0 END) as high_risk
       FROM cloud_resources GROUP BY cloud_provider, resource_type`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Metrics (for Prometheus) ──
app.get('/metrics', async (req, res) => {
  // In production, use prom-client
  res.set('Content-Type', 'text/plain');
  res.send(`
# HELP api_requests_total Total API requests
# TYPE api_requests_total counter
api_requests_total 1234

# HELP active_alerts Active security alerts
# TYPE active_alerts gauge
active_alerts 42
  `);
});

// ── Users (Admin only) ──
app.get('/api/users', authenticate, authorize('admin'), async (req, res) => {
  try {
    const result = await pgPool.query('SELECT id, username, role, created_at FROM users');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Start Server ─────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`🚀 API Server running on port ${PORT}`));

module.exports = { app, broadcastAlert };
