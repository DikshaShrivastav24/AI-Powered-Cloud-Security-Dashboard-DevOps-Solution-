// frontend/src/services/api.js
const BASE = import.meta.env.VITE_API_URL || "http://localhost:4000";

class ApiService {
  constructor() {
    this.token = localStorage.getItem("auth_token");
  }

  setToken(token) {
    this.token = token;
    if (token) localStorage.setItem("auth_token", token);
    else localStorage.removeItem("auth_token");
  }

  async request(path, options = {}) {
    const res = await fetch(`${BASE}${path}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(this.token ? { Authorization: `Bearer ${this.token}` } : {}),
        ...options.headers,
      },
    });
    if (res.status === 401) {
      this.setToken(null);
      window.location.href = "/login";
      throw new Error("Unauthorized");
    }
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(err.error || "API error");
    }
    return res.json();
  }

  // Auth
  async login(username, password) {
    const data = await this.request("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    });
    this.setToken(data.token);
    return data;
  }
  logout() {
    this.setToken(null);
  }

  // Dashboard
  getDashboardSummary()    { return this.request("/api/dashboard/summary"); }

  // Logs
  getLogs(params = {}) {
    const q = new URLSearchParams(params).toString();
    return this.request(`/api/logs?${q}`);
  }

  // Alerts
  getAlerts(params = {}) {
    const q = new URLSearchParams(params).toString();
    return this.request(`/api/alerts?${q}`);
  }
  updateAlert(id, data) {
    return this.request(`/api/alerts/${id}`, { method: "PATCH", body: JSON.stringify(data) });
  }

  // Threats
  getThreatScores()  { return this.request("/api/threats/scores"); }
  getAnomalies()     { return this.request("/api/threats/anomalies"); }

  // Compliance
  getCompliance()    { return this.request("/api/compliance"); }

  // Vulnerabilities
  getVulnerabilities(params = {}) {
    const q = new URLSearchParams(params).toString();
    return this.request(`/api/vulnerabilities?${q}`);
  }

  // Incidents
  getIncidents()     { return this.request("/api/incidents"); }
  createIncident(data) {
    return this.request("/api/incidents", { method: "POST", body: JSON.stringify(data) });
  }

  // Cloud Resources
  getCloudResources() { return this.request("/api/cloud/resources"); }
}

export const api = new ApiService();
