// frontend/src/App.jsx
import { useState, useEffect, useCallback } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Overview from "./pages/Overview";
import Alerts from "./pages/Alerts";
import ThreatMap from "./pages/ThreatMap";
import Compliance from "./pages/Compliance";
import Vulnerabilities from "./pages/Vulnerabilities";
import Incidents from "./pages/Incidents";
import Login from "./pages/Login";
import { AuthProvider, useAuth } from "./hooks/useAuth";
import { WebSocketProvider } from "./hooks/useWebSocket";
import "./App.css";

function ProtectedRoute({ children }) {
  const { user } = useAuth();
  return user ? children : <Navigate to="/login" replace />;
}

function AppLayout() {
  const [darkMode, setDarkMode] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", darkMode ? "dark" : "light");
  }, [darkMode]);

  return (
    <div className={`app-shell ${darkMode ? "dark" : "light"}`}>
      <Sidebar
        open={sidebarOpen}
        onToggle={() => setSidebarOpen((p) => !p)}
        darkMode={darkMode}
        onDarkModeToggle={() => setDarkMode((p) => !p)}
      />
      <main className={`main-content ${sidebarOpen ? "sidebar-open" : ""}`}>
        <Routes>
          <Route path="/" element={<Overview />} />
          <Route path="/alerts" element={<Alerts />} />
          <Route path="/threats" element={<ThreatMap />} />
          <Route path="/compliance" element={<Compliance />} />
          <Route path="/vulnerabilities" element={<Vulnerabilities />} />
          <Route path="/incidents" element={<Incidents />} />
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <WebSocketProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route
              path="/*"
              element={
                <ProtectedRoute>
                  <AppLayout />
                </ProtectedRoute>
              }
            />
          </Routes>
        </BrowserRouter>
      </WebSocketProvider>
    </AuthProvider>
  );
}
