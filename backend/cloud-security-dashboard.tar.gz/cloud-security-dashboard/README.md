# AI-Powered Cloud Security Dashboard – DevOps Solution

## Project Structure
```
cloud-security-dashboard/
├── frontend/              # React dashboard
├── backend/
│   ├── api/              # Node.js Express API
│   ├── ml/               # Python ML models
│   └── pipeline/         # Kafka + Fluentd pipeline
├── infrastructure/
│   ├── terraform/        # IaC for AWS/Azure/GCP
│   ├── kubernetes/       # K8s manifests
│   └── docker/           # Dockerfiles
├── monitoring/           # Prometheus + Grafana
└── docs/                 # Architecture + guides
```

## Quick Start
```bash
docker-compose up -d
```

## Full Deployment
See docs/DEPLOYMENT.md
