# infrastructure/terraform/main.tf
# ═══════════════════════════════════════════════════════════════
#  AI-Powered Cloud Security Dashboard – AWS Infrastructure
#  Deploy: terraform init && terraform apply
# ═══════════════════════════════════════════════════════════════

terraform {
  required_version = ">= 1.6"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.23"
    }
  }
  backend "s3" {
    bucket = "your-terraform-state-bucket"
    key    = "security-dashboard/terraform.tfstate"
    region = "us-east-1"
  }
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = {
      Project     = "security-dashboard"
      Environment = var.environment
      ManagedBy   = "terraform"
    }
  }
}

# ─── Variables ────────────────────────────────────────────────────────────────
variable "aws_region"    { default = "us-east-1" }
variable "environment"   { default = "production" }
variable "cluster_name"  { default = "security-eks" }
variable "vpc_cidr"      { default = "10.0.0.0/16" }

# ─── VPC ─────────────────────────────────────────────────────────────────────
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "5.1.2"

  name = "security-vpc"
  cidr = var.vpc_cidr

  azs             = ["${var.aws_region}a", "${var.aws_region}b", "${var.aws_region}c"]
  private_subnets = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
  public_subnets  = ["10.0.101.0/24", "10.0.102.0/24", "10.0.103.0/24"]

  enable_nat_gateway     = true
  single_nat_gateway     = false
  one_nat_gateway_per_az = true
  enable_dns_hostnames   = true
  enable_dns_support     = true

  public_subnet_tags = {
    "kubernetes.io/cluster/${var.cluster_name}" = "shared"
    "kubernetes.io/role/elb"                    = "1"
  }
  private_subnet_tags = {
    "kubernetes.io/cluster/${var.cluster_name}" = "shared"
    "kubernetes.io/role/internal-elb"           = "1"
  }
}

# ─── EKS Cluster ─────────────────────────────────────────────────────────────
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "19.21.0"

  cluster_name    = var.cluster_name
  cluster_version = "1.28"

  vpc_id                   = module.vpc.vpc_id
  subnet_ids               = module.vpc.private_subnets
  cluster_endpoint_public_access = true

  eks_managed_node_groups = {
    # General workloads
    general = {
      name           = "general-ng"
      instance_types = ["t3.medium"]
      min_size       = 2
      max_size       = 8
      desired_size   = 3
      disk_size      = 50
    }
    # ML workloads (larger instances)
    ml = {
      name           = "ml-ng"
      instance_types = ["c5.xlarge"]
      min_size       = 1
      max_size       = 4
      desired_size   = 2
      disk_size      = 100
      labels = {
        workload = "ml"
      }
      taints = [{
        key    = "workload"
        value  = "ml"
        effect = "NO_SCHEDULE"
      }]
    }
  }

  cluster_addons = {
    coredns    = { most_recent = true }
    kube-proxy = { most_recent = true }
    vpc-cni    = { most_recent = true }
    aws-ebs-csi-driver = { most_recent = true }
  }
}

# ─── ElasticSearch (OpenSearch) ───────────────────────────────────────────────
resource "aws_opensearch_domain" "security_logs" {
  domain_name    = "security-logs"
  engine_version = "OpenSearch_2.11"

  cluster_config {
    instance_type          = "r6g.large.search"
    instance_count         = 3
    dedicated_master_enabled = true
    dedicated_master_type  = "r6g.large.search"
    dedicated_master_count = 3
    zone_awareness_enabled = true
    zone_awareness_config {
      availability_zone_count = 3
    }
  }

  ebs_options {
    ebs_enabled = true
    volume_size = 100
    volume_type = "gp3"
  }

  encrypt_at_rest { enabled = true }
  node_to_node_encryption { enabled = true }

  advanced_security_options {
    enabled                        = true
    internal_user_database_enabled = true
    master_user_options {
      master_user_name     = "admin"
      master_user_password = "ChangeMe123!"
    }
  }

  domain_endpoint_options {
    enforce_https       = true
    tls_security_policy = "Policy-Min-TLS-1-2-2019-07"
  }

  vpc_options {
    subnet_ids         = [module.vpc.private_subnets[0], module.vpc.private_subnets[1]]
    security_group_ids = [aws_security_group.elasticsearch.id]
  }

  tags = { Name = "security-logs" }
}

# ─── RDS PostgreSQL ───────────────────────────────────────────────────────────
resource "aws_db_subnet_group" "security" {
  name       = "security-db-subnet"
  subnet_ids = module.vpc.private_subnets
}

resource "aws_db_instance" "security_db" {
  identifier        = "security-db"
  engine            = "postgres"
  engine_version    = "16.1"
  instance_class    = "db.t3.medium"
  allocated_storage = 50
  storage_type      = "gp3"
  storage_encrypted = true

  db_name  = "security_db"
  username = "admin"
  password = "ChangeMe123!"  # Use Secrets Manager in production

  vpc_security_group_ids = [aws_security_group.rds.id]
  db_subnet_group_name   = aws_db_subnet_group.security.name

  multi_az               = true
  backup_retention_period = 7
  deletion_protection    = true
  skip_final_snapshot    = false

  tags = { Name = "security-db" }
}

# ─── MSK (Managed Kafka) ─────────────────────────────────────────────────────
resource "aws_msk_cluster" "security_kafka" {
  cluster_name           = "security-kafka"
  kafka_version          = "3.6.0"
  number_of_broker_nodes = 3

  broker_node_group_info {
    instance_type   = "kafka.t3.small"
    client_subnets  = module.vpc.private_subnets
    security_groups = [aws_security_group.kafka.id]
    storage_info {
      ebs_storage_info { volume_size = 100 }
    }
  }

  encryption_info {
    encryption_in_transit {
      client_broker = "TLS"
      in_cluster    = true
    }
  }

  tags = { Name = "security-kafka" }
}

# ─── Security Groups ──────────────────────────────────────────────────────────
resource "aws_security_group" "elasticsearch" {
  name   = "security-es-sg"
  vpc_id = module.vpc.vpc_id
  ingress {
    from_port       = 443
    to_port         = 443
    protocol        = "tcp"
    security_groups = [module.eks.node_security_group_id]
  }
}

resource "aws_security_group" "rds" {
  name   = "security-rds-sg"
  vpc_id = module.vpc.vpc_id
  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [module.eks.node_security_group_id]
  }
}

resource "aws_security_group" "kafka" {
  name   = "security-kafka-sg"
  vpc_id = module.vpc.vpc_id
  ingress {
    from_port       = 9092
    to_port         = 9092
    protocol        = "tcp"
    security_groups = [module.eks.node_security_group_id]
  }
  ingress {
    from_port       = 9094
    to_port         = 9094
    protocol        = "tcp"
    security_groups = [module.eks.node_security_group_id]
  }
}

# ─── CloudWatch Log Group ─────────────────────────────────────────────────────
resource "aws_cloudwatch_log_group" "security_dashboard" {
  name              = "/aws/security-dashboard"
  retention_in_days = 90
}

# ─── Outputs ─────────────────────────────────────────────────────────────────
output "eks_cluster_endpoint"     { value = module.eks.cluster_endpoint }
output "eks_cluster_name"         { value = module.eks.cluster_name }
output "opensearch_endpoint"      { value = aws_opensearch_domain.security_logs.endpoint }
output "rds_endpoint"             { value = aws_db_instance.security_db.endpoint }
output "kafka_bootstrap_brokers"  { value = aws_msk_cluster.security_kafka.bootstrap_brokers_tls }
